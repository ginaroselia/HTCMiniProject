# Full Dataset Check Labelled > Full Dataset for Object Detection_v1_180725
https://universe.roboflow.com/bootcamp-group-project/full-dataset-check-labelled

Provided by a Roboflow user
License: CC BY 4.0

